# Codex Finance Skills

This package contains a GitHub-ready set of Codex skills for China/A-share finance workflows.

## Included Skills

- `mx-data`: authoritative Eastmoney MX financial data lookup for quotes, financials, fundamentals, shareholders, and entity relationships.
- `mx-search`: finance-specific Eastmoney MX information retrieval for news, announcements, research reports, policy, and event analysis.
- `mx-xuangu`: Eastmoney MX condition-based stock screening and universe/constituent lookup.
- `mx-zixuan`: Eastmoney MX self-selected stock watchlist query/add/delete actions.
- `mx-moni`: Eastmoney MX simulated portfolio query and simulated trading actions.
- `alphaear-logic-visualizer`: Draw.io-compatible finance logic and transmission-chain diagrams.
- `alphaear-signal-tracker`: investment signal evolution tracking against new market facts.

## Install

Copy the skill folders into your Codex skills directory:

```bash
mkdir -p "${CODEX_HOME:-$HOME/.codex}/skills"
cp -R skills/* "${CODEX_HOME:-$HOME/.codex}/skills/"
```

Restart or refresh Codex so the skills are rediscovered.

## Environment

The `mx-*` skills require:

```bash
export MX_APIKEY="your_eastmoney_mx_api_key"
```

Never commit a real `MX_APIKEY` value to GitHub. Keep it in your local shell, CI secret store, or private environment manager. See `SECURITY.md`.

Optional output directory override:

```bash
export MX_OUTPUT_DIR="$HOME/.codex/skills-output/mx_data/output"
```

Without `MX_OUTPUT_DIR`, the scripts default to `~/.codex/skills-output/mx_data/output`.

## Validate

If the Codex system `skill-creator` validator is available locally:

```bash
for d in skills/*; do
  python "$HOME/.codex/skills/.system/skill-creator/scripts/quick_validate.py" "$d"
done
```

Each skill also includes lightweight `evals/evals.json` files with positive and negative routing examples.

## Notes

- This package does not include API keys, generated query outputs, or local caches.
- Account-mutating actions exist in `mx-zixuan` and `mx-moni`; read those `SKILL.md` files before use.
- Finance outputs are research aids and do not constitute investment advice.
